1.

$$
\exists leak_{ratio}\in\mathbb{R}:\quad\begin{cases}leak_{ratio} - \frac{2}{3}=0 \\ \frac{16}{27} - 2 leak_{ratio}^{3}\ne0\end{cases}
$$

2.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}\frac{5 x}{6} - 5=0 \\ x - 6\ne0\end{cases}
$$

3.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}5 x - 15=0 \\ 6 x - 18\ne0\end{cases}
$$

4.

$$
\exists (a, b)\in\mathbb{R}^{2}:\quad\begin{cases}a - \frac{3139}{10}=0 \\ b - \frac{63}{5}=0 \\ a + b - \frac{653}{2}\ne0\end{cases}
$$

5.

$$
\exists exchange_{rate}\in\mathbb{R}:\quad\begin{cases}exchange_{rate} - \frac{1}{800}=0 \\ 1000000 exchange_{rate} - 1250\ne0\end{cases}
$$

6.

$$
\exists (speed, distance_{hallway})\in\mathbb{R}^{2}:\quad\begin{cases}speed - \frac{2}{5}=0 \\ distance_{hallway} - \frac{speed}{40}=0 \\ 1000 distance_{hallway} - 10\ne0\end{cases}
$$

7.

$$
\exists (smallest_{angle}, largest_{angle}, sum_{of angles})\in\mathbb{R}^{3}:\quad\begin{cases}largest_{angle} - 2 smallest_{angle}=0 \\ sum_{of angles} - 360=0 \\ - largest_{angle} - smallest_{angle} + sum_{of angles} - 180=0 \\ largest_{angle} - 120\ne0\end{cases}
$$

8.

$$
\exists (x, y, z)\in\mathbb{R}^{3}:\quad\begin{cases}9 x - 7=0 \\ 9 y - 4=0 \\ 9 z - 2=0 \\ - x + y - z + \frac{5}{9}\ne0\end{cases}
$$

9.

$$
\exists (s, original_{area}, new_{area})\in\mathbb{R}^{3}:\quad\begin{cases}s>0 \\ original_{area} - s^{2}=0 \\ new_{area} - \frac{9 s^{2}}{10}=0 \\ - 100 new_{area} + 90 original_{area}\ne0\end{cases}
$$

10.

$$
\exists (s, original_{area}, new_{area})\in\mathbb{R}^{3}:\quad\begin{cases}s>0 \\ original_{area} - s^{2}=0 \\ new_{area} - \frac{9 s^{2}}{10}=0\end{cases}
$$

11.

$$
\exists (sale_{price}, original_{price})\in\mathbb{R}^{2}:\quad\begin{cases}sale_{price} - \frac{72}{5}=0 \\ - \frac{2 original_{price}}{5} + sale_{price}=0 \\ original_{price} - 36\ne0\end{cases}
$$

12.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}\frac{x}{4} - \frac{17}{4}=0 \\ x - 17\ne0\end{cases}
$$

13.

$$
\exists (x, first, second, result)\in\mathbb{R}^{4}:\quad\begin{cases}first - 19 x - 1=0 \\ second - 4 x - 81=0 \\ - first + result + second=0 \\ result - 15 x + 80\ne0\end{cases}
$$

14.

$$
\exists (y, dot_{product}, norm_{squared}, projection_{scale})\in\mathbb{R}^{4}:\quad\begin{cases}dot_{product} + 2 y + 3=0 \\ norm_{squared} - 6=0 \\ - dot_{product} + norm_{squared} projection_{scale}=0 \\ projection_{scale} - \frac{5}{6}=0 \\ y + 4\ne0\end{cases}
$$

15.

$$
\exists (x, factor, first_{product}, second_{product}, value)\in\mathbb{R}^{5}:\quad\begin{cases}x - 4=0 \\ factor - 3 x + 2=0 \\ - 4 factor x - factor + first_{product}=0 \\ - 4 factor x + second_{product}=0 \\ - first_{product} + second_{product} + value - 1=0 \\ value - 11\ne0\end{cases}
$$

16.

$$
\exists (treek, squig, goolee)\in\mathbb{R}^{3}:\quad\begin{cases}treek>0 \\ - goolee - 3 squig + 10 treek=0 \\ goolee - squig + 2 treek=0 \\ squig - 3 treek\ne0\end{cases}
$$

17.

$$
\exists (x, square_{root})\in\mathbb{R}^{2}:\quad\begin{cases}square_{root}\ge0 \\ square_{root}^{2} - 3 x + 5=0 \\ square_{root} - 2=0 \\ x - 3\ne0\end{cases}
$$

18.

$$
\exists (x, square_{root})\in\mathbb{R}^{2}:\quad\begin{cases}square_{root}\ge0 \\ square_{root}^{2} - 3 x + 5=0 \\ square_{root} - 2=0\end{cases}
$$

19.

$$
\exists (x, left_{square}, right_{square}, radicand)\in\mathbb{R}^{4}:\quad\begin{cases}left_{square} - x^{2} + 6 x - 9=0 \\ right_{square} - x^{2} + 16 x - 64=0 \\ - left_{square} + radicand + right_{square}=0 \\ radicand\ge0 \\ x - \frac{11}{2}<0\end{cases}
$$

20.

$$
\exists (x, left_{square}, right_{square}, radicand)\in\mathbb{R}^{4}:\quad\begin{cases}left_{square} - x^{2} + 6 x - 9=0 \\ right_{square} - x^{2} + 16 x - 64=0 \\ - left_{square} + radicand + right_{square}=0 \\ radicand\ge0 \\ x - \frac{11}{2}=0\end{cases}
$$

21.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}x^{2} - x - 1=0 \\ x^{3} - 2 x - 1\ne0\end{cases}
$$

22.

$$
\exists (a, b)\in\mathbb{R}^{2}:\quad\begin{cases}3 b - 6=0 \\ 4 a + 5 b + 2=0 \\ a b + 6=0 \\ - 2 a - 6=0 \\ a + b + 1\ne0\end{cases}
$$

23.

$$
\exists (a, b)\in\mathbb{R}^{2}:\quad\begin{cases}3 b - 6=0 \\ 4 a + 5 b + 2=0 \\ a b + 6=0 \\ - 2 a - 6=0\end{cases}
$$

24.

$$
\exists (b, c)\in\mathbb{R}^{2}:\quad\begin{cases}\frac{13}{5} - 2 b=0 \\ - b^{2} - c + \frac{18}{5}=0 \\ b + c - \frac{321}{100}\ne0\end{cases}
$$

25.

$$
\exists (b, c)\in\mathbb{R}^{2}:\quad\begin{cases}\frac{13}{5} - 2 b=0 \\ - b^{2} - c + \frac{18}{5}=0\end{cases}
$$

26.

$$
\exists (a_{1}, d)\in\mathbb{R}^{2}:\quad\begin{cases}a_{1} + 3 d - 200=0 \\ a_{1} + 7 d - 500=0 \\ a_{1} + 5 d - 350\ne0\end{cases}
$$

27.

$$
\exists (B, h)\in\mathbb{R}^{2}:\quad\begin{cases}B - 30=0 \\ h - \frac{13}{2}=0 \\ - \frac{B h}{3} + 65\ne0\end{cases}
$$

28.

$$
\exists (x, \mathcal{recipro})\in\mathbb{R}^{2}:\quad\begin{cases}x - 5\ne0 \\ \mathcal{recipro} x - 5 \mathcal{recipro} - 1=0 \\ 4 \mathcal{recipro} - \frac{2}{3}=0 \\ x - 11\ne0\end{cases}
$$

29.

$$
\exists (x, \mathcal{recipro})\in\mathbb{R}^{2}:\quad\begin{cases}x - 5\ne0 \\ \mathcal{recipro} x - 5 \mathcal{recipro} - 1=0 \\ 4 \mathcal{recipro} - \frac{2}{3}=0\end{cases}
$$

30.

$$
\exists (a, b, c)\in\mathbb{R}^{3}:\quad\begin{cases}a + b - 8=0 \\ b + c + 3=0 \\ a + c + 5=0 \\ a b c + 120\ne0\end{cases}
$$

31.

$$
\exists (a, b)\in\mathbb{R}^{2}:\quad\begin{cases}3 a + 2 b - 12=0 \\ a - 4=0 \\ b\ne0\end{cases}
$$

32.

$$
\exists (u, first_{product}, second_{product}, result)\in\mathbb{R}^{4}:\quad\begin{cases}first_{product} - u^{2} - 3 u + 4=0 \\ second_{product} - u^{2} - 3 u + 18=0 \\ - first_{product} + result + second_{product}=0 \\ result - 14\ne0\end{cases}
$$

33.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}1600 - x=0 \\ x - 1600\ne0\end{cases}
$$

34.

$$
\exists x\in\mathbb{R}:\quad - 4 x^{2} - 20 x - 25>0
$$

35.

$$
\exists x\in\mathbb{R}:\quad - 4 x^{2} - 20 x - 25=0
$$

36.

$$
\exists (a, b, m)\in\mathbb{R}^{3}:\quad\begin{cases}\frac{a}{4} - 1=0 \\ \frac{b}{12} - 1=0 \\ a\ne0 \\ a m + b=0 \\ a + b + m - 13\ne0\end{cases}
$$

37.

$$
\exists (a, b, m)\in\mathbb{R}^{3}:\quad\begin{cases}\frac{a}{4} - 1=0 \\ \frac{b}{12} - 1=0 \\ a\ne0 \\ a m + b=0\end{cases}
$$

38.

$$
\exists (x_{1}, x_{2})\in\mathbb{R}^{2}:\quad\begin{cases}x_{1} - x_{2}\ne0 \\ x_{1}^{2} - 8 x_{1} - 128=0 \\ x_{2}^{2} - 8 x_{2} - 128=0 \\ x_{1} x_{2} + 128\ne0\end{cases}
$$

39.

$$
\exists (x_{1}, x_{2})\in\mathbb{R}^{2}:\quad\begin{cases}x_{1} - x_{2}\ne0 \\ x_{1}^{2} - 8 x_{1} - 128=0 \\ x_{2}^{2} - 8 x_{2} - 128=0\end{cases}
$$

40.

$$
\exists r\in\mathbb{R}:\quad\begin{cases}2 r - 7\ne0 \\ - 2 r^{2} + 15 r - 28=0 \\ r - 4\ne0\end{cases}
$$

41.

$$
\exists r\in\mathbb{R}:\quad\begin{cases}2 r - 7\ne0 \\ - 2 r^{2} + 15 r - 28=0\end{cases}
$$

42.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}x^{2} + 3 x - 4=0 \\ x^{2} + 9 x + 20=0 \\ x + 4\ne0\end{cases}
$$

43.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}x^{2} + 3 x - 4=0 \\ x^{2} + 9 x + 20=0\end{cases}
$$

44.

$$
\exists (a, b, c)\in\mathbb{R}^{3}:\quad\begin{cases}2 a - 10=0 \\ 6 - 2 b=0 \\ - a^{2} - b^{2} + c + 1=0 \\ c - 33\ne0\end{cases}
$$

45.

$$
\exists (a, b, c)\in\mathbb{R}^{3}:\quad\begin{cases}2 a - 10=0 \\ 6 - 2 b=0 \\ - a^{2} - b^{2} + c + 1=0\end{cases}
$$

46.

$$
\exists (x, \mathcal{recipro})\in\mathbb{R}^{2}:\quad\begin{cases}x\ne0 \\ \mathcal{recipro} x - 1=0 \\ 3 - 6 \mathcal{recipro}=0 \\ x - 2\ne0\end{cases}
$$

47.

$$
\exists (x, \mathcal{recipro})\in\mathbb{R}^{2}:\quad\begin{cases}x\ne0 \\ \mathcal{recipro} x - 1=0 \\ 3 - 6 \mathcal{recipro}=0\end{cases}
$$

48.

$$
\exists (speed, time, distance)\in\mathbb{R}^{3}:\quad\begin{cases}speed - 50=0 \\ time - \frac{11}{4}=0 \\ distance - speed time=0 \\ distance - \frac{275}{2}\ne0\end{cases}
$$

49.

$$
\exists (speed, time, distance)\in\mathbb{R}^{3}:\quad\begin{cases}speed - 50=0 \\ time - \frac{11}{4}=0 \\ distance - speed time=0\end{cases}
$$

50.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}x - 4\ge0 \\ 11 - 2 x\ge0 \\ x^{2} - 6 x + 5=0 \\ x - 5\ne0\end{cases}
$$

51.

$$
\exists x\in\mathbb{R}:\quad\begin{cases}x - 4\ge0 \\ 11 - 2 x\ge0 \\ x^{2} - 6 x + 5=0\end{cases}
$$

52.

$$
\exists (x, numerator, denominator, value)\in\mathbb{R}^{4}:\quad\begin{cases}x>0 \\ numerator - x^{2} - 7 x - 10=0 \\ denominator - x - 1=0 \\ denominator>0 \\ denominator value - numerator=0 \\ value - 9<0\end{cases}
$$

53.

$$
\exists (x, numerator, denominator, value)\in\mathbb{R}^{4}:\quad\begin{cases}x>0 \\ numerator - x^{2} - 7 x - 10=0 \\ denominator - x - 1=0 \\ denominator>0 \\ denominator value - numerator=0 \\ value - 9=0\end{cases}
$$

54.

$$
\exists (x, y, z)\in\mathbb{R}^{3}:\quad\begin{cases}x>0 \\ y>0 \\ z>0 \\ x^{2} y z + x y^{2} z + x y z^{2} - 1=0 \\ x y + x z + y^{2} + y z - 2<0\end{cases}
$$

55.

$$
\exists (x, y, z)\in\mathbb{R}^{3}:\quad\begin{cases}x>0 \\ y>0 \\ z>0 \\ x^{2} y z + x y^{2} z + x y z^{2} - 1=0 \\ x y + x z + y^{2} + y z - 2=0\end{cases}
$$

56.

$$
\exists (a, b, c, d, e)\in\mathbb{R}^{5}:\quad\begin{cases}a + b + c + d + e - 8=0 \\ a^{2} + b^{2} + c^{2} + d^{2} + e^{2} - 16=0 \\ e - \frac{16}{5}>0\end{cases}
$$

57.

$$
\exists (a, b, c, d, e)\in\mathbb{R}^{5}:\quad\begin{cases}a + b + c + d + e - 8=0 \\ a^{2} + b^{2} + c^{2} + d^{2} + e^{2} - 16=0 \\ e - \frac{16}{5}=0\end{cases}
$$

58.

$$
\exists (x, y, z)\in\mathbb{R}^{3}:\quad\begin{cases}x>0 \\ y>0 \\ z>0 \\ x y - 24=0 \\ x z - 48=0 \\ y z - 72=0 \\ x + y + z - 22\ne0\end{cases}
$$

59.

$$
\exists (x, y, z)\in\mathbb{R}^{3}:\quad\begin{cases}x>0 \\ y>0 \\ z>0 \\ x y - 24=0 \\ x z - 48=0 \\ y z - 72=0\end{cases}
$$

60.

$$
\exists (a, b, factor_{1}, factor_{2}, result)\in\mathbb{R}^{5}:\quad\begin{cases}- a + factor_{1} - 5=0 \\ - b + factor_{2} - 2=0 \\ - a b - 2 a - 5 b + result - 10=0 \\ - factor_{1} factor_{2} + result\ne0\end{cases}
$$
