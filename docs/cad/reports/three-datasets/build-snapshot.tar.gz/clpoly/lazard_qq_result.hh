/** Lazard 求值结果：QQ 代表、变量序所有权及逐坐标阶数。 */
#ifndef CLPOLY_LAZARD_QQ_RESULT_HH
#define CLPOLY_LAZARD_QQ_RESULT_HH
#include <clpoly/polynomial.hh>
#include <memory>
#include <vector>

namespace clpoly
{
struct lazard_qq_result
{
    using order_type = lex_<custom_var_order>;

    // 代表多项式借用此比较器；其数值须相对于调用方保留的同一个前缀点解释。
    std::shared_ptr<const order_type> order;
    polynomial_<QQ, order_type> polynomial;
    std::vector<size_t> valuation;

    explicit lazard_qq_result(std::shared_ptr<const order_type> o)
        : order(std::move(o)), polynomial(order.get())
    {
    }
};
} // 命名空间 clpoly
#endif
