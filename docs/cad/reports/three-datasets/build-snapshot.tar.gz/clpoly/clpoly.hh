/**
 * @file clpoly.hh
 * @author 李昊坤 (ker@pm.me)
 * @brief 总启动文件
 * 
 */
#ifndef CLPOLY_HH
#define CLPOLY_HH
#include <clpoly/rational_interval.hh>
#include <clpoly/rational_sample.hh>
#include <clpoly/polynomial.hh>
#include <clpoly/resultant.hh>
#include <clpoly/polynomial_gcd.hh>
#include <clpoly/upolynomial.hh>
#include <clpoly/polynomial_factorize.hh>
#include <clpoly/random.hh>
#include <clpoly/associatedgraph.hh>
#include <clpoly/realroot.hh>
#include <clpoly/charset.hh>
#include <clpoly/cad.hh>
#include <clpoly/full_cad.hh>
#include <clpoly/groebner.hh>
// #include <clpoly/interval.hh>


#endif
