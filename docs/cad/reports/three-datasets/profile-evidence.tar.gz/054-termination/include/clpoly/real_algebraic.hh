/** 基于 QQ 三角列的 XZ06 实代数点证书。
 * 伪代码见 docs/cad/theory/lazard-evaluation.pdf，算法 1–6、9–11。
 */
#ifndef CLPOLY_REAL_ALGEBRAIC_HH
#define CLPOLY_REAL_ALGEBRAIC_HH
#include <clpoly/triangular_set.hh>
#include <clpoly/polynomial_interval.hh>
#include <clpoly/realroot.hh>
namespace clpoly
{
namespace xz_detail
{
using P = triangular_set::polynomial_type;
using U = std::vector<QQ>; // 按次数递增存放的稠密 QQ 系数。
using I = rational_interval;
inline QQ eval(const U &f, const QQ &x)
{
    QQ v(0);
    for (size_t j = f.size(); j-- > 0;)
    {
        v = v * x + f[j];
    }
    return v;
}
inline I eval(const U &f, const I &x)
{
    I v;
    for (size_t j = f.size(); j-- > 0;)
    {
        v = v * x + I(f[j]);
    }
    return v;
}
inline U derivative_u(const U &f)
{
    U d(f.empty() ? 0 : f.size() - 1);
    for (size_t j = 1; j < f.size(); ++j)
    {
        d[j - 1] = f[j] * QQ(ZZ(j));
    }
    return d;
}
inline std::vector<P> coefficients(const P &f, const variable &v)
{
    std::vector<P> c(static_cast<size_t>(std::max<int64_t>(0, degree(f, v))) + 1, P(f.comp_ptr()));
    for (const auto &term : f)
    {
        auto d = term.first.deg(v);
        basic_monomial<triangular_set::order_type> power(f.comp_ptr());
        if (d)
        {
            power = {{v, d}};
        }
        c[d].push_back({d ? term.first / power : term.first, term.second});
    }
    for (auto &coefficient : c)
    {
        coefficient.normalization();
    }
    return c;
}
inline P translate(const P &f, const variable &v, const QQ &offset)
{
    // 在 QQ 多项式中展开 f(u,v+offset)，再对其系数做区间估值。
    auto c = coefficients(f, v);
    P result(f.comp_ptr()), linear(f.comp_ptr());
    basic_monomial<triangular_set::order_type> vm(f.comp_ptr()), one(f.comp_ptr());
    vm = {{v, 1}};
    linear.push_back({vm, QQ(1)});
    if (offset != QQ(0))
    {
        linear.push_back({one, offset});
    }
    for (size_t i = c.size(); i-- > 0;)
    {
        result = result * linear + c[i];
    }
    return result;
}
// 逐系数包络仅在新变量 v>0 时给出多项式及各阶导数的上下界。
// 调用方先把全部根平移到正半轴，再使用该性质。
inline std::pair<U, U> bounds(const P &f, const variable &v, const std::vector<variable> &vars,
                              const std::vector<I> &box)
{
    auto c = coefficients(f, v);
    U l(c.size()), u(c.size());
    // 三角列的根盒按提升序存放；同步反转一次即可复用字典序求值核心。
    const std::vector<variable> ordered_vars(vars.rbegin(), vars.rend());
    const std::vector<I> ordered_box(box.rbegin(), box.rend());
    for (size_t j = 0; j < c.size(); ++j)
    {
        auto b = __assign_interval(c[j], ordered_vars, ordered_box);
        l[j] = b.left();
        u[j] = b.right();
    }
    return {l, u};
}
inline upolynomial_ZZ integer(const U &f)
{
    ZZ denominator(1);
    for (const auto &q : f)
    {
        denominator = (denominator / gcd(denominator, q.den())) * q.den();
    }
    upolynomial_ZZ z;
    for (size_t j = f.size(); j-- > 0;)
    {
        if (f[j] != QQ(0))
        {
            z.push_back({umonomial(j), f[j].num() * (denominator / f[j].den())});
        }
    }
    return z;
}
inline bool squarefree(const U &f)
{
    cad_diag::Scope d("SQUAREFREE-GCD");
    auto z = integer(f);
    if (z.empty())
    {
        return false;
    }
    if (z.front().first.deg() == 0)
    {
        return true;
    }
#ifdef CLPOLY_DIAG_PLAIN_GCD
    auto g = polynomial_GCD(z, derivative(z));
#else
    upolynomial_ZZ s, t;
    auto g = polynomial_GCD(z, derivative(z), s, t);
#endif
    return !g.empty() && g.front().first.deg() == 0;
}
inline bool strict_sign(int s)
{
    return s == -1 || s == 1;
}
// 精化包含唯一单根的严格括区间。中点恰为根时，在其两侧保留更小的
// 严格区间，避免把精化证书退化成单点。
inline I bracket(const U &f, I b, const QQ &epsilon)
{
    if (epsilon <= QQ(0))
    {
        throw std::invalid_argument("BRACKET: nonpositive precision");
    }
    int left = sgn(eval(f, b.left())), right = sgn(eval(f, b.right()));
    if (!left || !right || left == right)
    {
        throw std::logic_error("BRACKET: invalid strict bracket");
    }
    while (b.width() > epsilon)
    {
        const QQ m = b.midpoint();
        const int middle = sgn(eval(f, m));
        if (!middle)
        {
            const QQ delta = std::min(b.width() / QQ(4), epsilon / QQ(4));
            b = I(m - delta, m + delta);
        }
        else if (middle == left)
        {
            b = I(m, b.right());
        }
        else
        {
            b = I(b.left(), m);
        }
    }
    return b;
}
// PDF 算法 11（UNI-QQ）：适配既有非零根隔离器，返回全部根的有序列表，
// 每个根都有严格括区间和导数符号证书。
inline std::vector<I> univariate(const U &f, const QQ &epsilon)
{
    cad_diag::Scope d("UNI");cad_diag::uinfo("UNI-input",f);
    if (epsilon <= QQ(0))
    {
        throw std::invalid_argument("UNI: nonpositive precision");
    }
    auto z = integer(f);
    if (z.empty())
    {
        throw std::domain_error("UNI: zero polynomial");
    }
    if (z.front().first.deg() == 0)
    {
        return {};
    }
    if (!squarefree(f))
    {
        throw std::invalid_argument("UNI: squarefree polynomial required");
    }
    std::vector<I> out;
    const U df = derivative_u(f);
    // 已审核的标量 Uspensky 接口只返回非零根；先补入可能存在的简单零根，
    // 再统一转换成严格括区间。
    auto roots = [&](){cad_diag::Scope d("USPENSKY");return uspensky(z);}();
    if (f.front() == QQ(0))
    {
        roots.emplace_back(QQ(0), QQ(0));
    }
    for (auto endpoints : roots)
    {
        I b(endpoints.first, endpoints.second);
        if (eval(f, b.left()) == QQ(0) || eval(f, b.right()) == QQ(0))
        {
            const QQ root = eval(f, b.left()) == QQ(0) ? b.left() : b.right();
            QQ delta = epsilon / QQ(4);
            do
            {
                b = I(root - delta, root + delta);
                delta /= QQ(2);
            } while (!strict_sign(eval(df, b).sgn()) ||
                     sgn(eval(f, b.left())) * sgn(eval(f, b.right())) != -1);
        }
        b = bracket(f, b, epsilon);
        while (!strict_sign(eval(df, b).sgn()))
        {
            b = bracket(f, b, b.width() / QQ(2));
        }
        out.push_back(std::move(b));
    }
    std::sort(out.begin(), out.end(), [](const I &a, const I &b) { return a.left() < b.left(); });
    for (size_t j = 1; j < out.size(); ++j)
    {
        while (out[j - 1].overlaps(out[j]))
        {
            out[j - 1] = bracket(f, out[j - 1], out[j - 1].width() / QQ(2));
            out[j] = bracket(f, out[j], out[j].width() / QQ(2));
        }
    }
    return out;
}
// 正半轴上，两界导数严格同号、端点严格异号，保证前缀盒中每个点的
// 专门化在该区间内恰有一个根。
inline bool certified(const std::pair<U, U> &b, const I &j)
{
    const int dl = eval(derivative_u(b.first), j).sgn(), du = eval(derivative_u(b.second), j).sgn();
    if (b.first.size() >= 9) std::cerr << "CERT-TEST degree=" << b.first.size()-1
        << " positive=" << (j.left()>QQ(0)) << " derivative-signs=" << dl << "," << du
        << " endpoint-signs=" << sgn(eval(b.first,j.left())) << "," << sgn(eval(b.second,j.left()))
        << ";" << sgn(eval(b.first,j.right())) << "," << sgn(eval(b.second,j.right())) << std::endl;
    return strict_sign(dl) && dl == du && sgn(eval(b.first, j.left())) == -dl &&
           sgn(eval(b.second, j.left())) == -dl && sgn(eval(b.first, j.right())) == dl &&
           sgn(eval(b.second, j.right())) == dl;
}
} // 命名空间 xz_detail

// 实点保存平方自由正则链、严格 QQ 根盒和固定平移。公开构造验证证书，
// 根隔离与精化由独立函数实现。
class real_algebraic_point
{
    triangular_set chain_;
    std::vector<rational_interval> box_;
    std::vector<QQ> shifts_;

public:
    real_algebraic_point() = default;
    real_algebraic_point(triangular_set chain, std::vector<rational_interval> box,
                         std::vector<QQ> shifts = {})
        : chain_(std::move(chain)), box_(std::move(box))
    {
        using namespace xz_detail;
        if (!chain_.is_squarefree() || chain_.size() != box_.size() ||
            (!shifts.empty() && shifts.size() != box_.size()))
        {
            throw std::invalid_argument(
                "real_algebraic_point: requires squarefree regular chain and matching box");
        }
        for (size_t i = 0; i < box_.size(); ++i)
        {
            if (box_[i].is_point())
            {
                throw std::invalid_argument("real_algebraic_point: strict brackets required");
            }
            QQ shift = shifts.empty() ? (box_[i].left() > QQ(0) ? QQ(0) : QQ(1) - box_[i].left())
                                      : shifts[i];
            if (box_[i].left() + shift <= QQ(0))
            {
                throw std::invalid_argument("real_algebraic_point: nonpositive shifted bracket");
            }
            auto f = translate(chain_.equations()[i], chain_.variables()[i], -shift);
            auto b = bounds(
                f, chain_.variables()[i],
                std::vector<variable>(chain_.variables().begin(), chain_.variables().begin() + i),
                std::vector<I>(box_.begin(), box_.begin() + i));
            if (!certified(b, box_[i] + I(shift)))
            {
                throw std::invalid_argument("real_algebraic_point: uncertified root box");
            }
            shifts_.push_back(shift);
        }
    }
    const triangular_set &chain() const
    {
        return chain_;
    }
    const std::vector<rational_interval> &box() const
    {
        return box_;
    }
    const std::vector<QQ> &shifts() const
    {
        return shifts_;
    }
    size_t size() const
    {
        return box_.size();
    }
    QQ max_width() const
    {
        QQ m(0);
        for (const auto &b : box_)
        {
            m = std::max(m, b.width());
        }
        return m;
    }
    real_algebraic_point prefix(size_t n) const
    {
        if (n > size())
        {
            throw std::out_of_range("real_algebraic_point: prefix");
        }
        // 前缀继承已经验证的证书，只截取数据，不重新平移或认证。
        real_algebraic_point result;
        result.chain_ = chain_.prefix(n);
        result.box_.assign(box_.begin(), box_.begin() + n);
        result.shifts_.assign(shifts_.begin(), shifts_.begin() + n);
        return result;
    }
    // 成员函数仅转发，算法定义在类型之外。
    void shrink();
    void refine(const QQ &epsilon);
    friend void shrink(real_algebraic_point &a);
    friend std::vector<real_algebraic_point> __lift_real_points(const triangular_set &chain,
                                                                real_algebraic_point prefix);
};

// PDF 算法 2（NSHR-QQ）：从第一坐标向上精化，每层使用已经缩小的前缀
// 和原有固定平移。定义链与所选实点保持不变。
inline void shrink(real_algebraic_point &a)
{
    using namespace xz_detail;
    for (size_t i = 0; i < a.size(); ++i)
    {
        auto q = translate(a.chain_.equations()[i], a.chain_.variables()[i], -a.shifts_[i]);
        auto b = bounds(
            q, a.chain_.variables()[i],
            std::vector<variable>(a.chain_.variables().begin(), a.chain_.variables().begin() + i),
            std::vector<I>(a.box_.begin(), a.box_.begin() + i));
        auto old = a.box_[i] + I(a.shifts_[i]);
        QQ epsilon = old.width() / QQ(i ? 8 : 2);
        auto l = bracket(b.first, old, epsilon), u = bracket(b.second, old, epsilon);
        a.box_[i] = hull(l, u) - I(a.shifts_[i]);
    }
}

// PDF 算法 3（REFINE）：将每维宽度缩至严格小于目标精度。
// 终止性依赖 NSHR-QQ 的收敛证明，不设置固定迭代次数。
inline void refine(real_algebraic_point &a, const QQ &epsilon)
{
    if (epsilon <= QQ(0))
    {
        throw std::invalid_argument("REFINE: nonpositive precision");
    }
    while (a.max_width() >= epsilon)
    {
        shrink(a);
    }
}
inline void real_algebraic_point::shrink()
{
    clpoly::shrink(*this);
}
inline void real_algebraic_point::refine(const QQ &epsilon)
{
    clpoly::refine(*this, epsilon);
}

namespace xz_detail
{
// PDF 算法 1（XZ-LIFT）：输入首项在指定点上非零。精化前缀，直到上下界
// 认证全部根；后续 NSHR-QQ 保持 used_shift 不变。全过程只构造 QQ 多项式。
inline std::vector<I> lift(const P &f, const variable &v, real_algebraic_point &a, QQ &used_shift)
{
    cad_diag::Scope d("XZ-LIFT");
    static size_t calls=0;const size_t call=++calls;
    std::cerr<<"XZ-ENTER call="<<call<<" variable="<<v<<" degree="<<degree(f,v)<<" polynomial="<<f<<std::endl;
    for(size_t k=0;k<a.size();++k)std::cerr<<"  prefix-equation="<<a.chain().equations()[k]<<" box="<<a.box()[k]<<std::endl;
    const auto &vars = a.chain().variables();
    auto cs = coefficients(f, v);
    if (cs.size() < 2)
    {
        return {};
    }
    I leading;
    while (true)
    {
        leading = assign_interval(cs.back(), vars, a.box());
        if (!leading.contains_zero())
        {
            break;
        }
        if (a.size() == 0)
        {
            throw std::domain_error("XZ-LIFT: zero leading coefficient");
        }
        a.refine(a.max_width() / QQ(2));
    }
    QQ m = std::min(abs(leading.left()), abs(leading.right())), maximum(0);
    for (size_t i = 0; i + 1 < cs.size(); ++i)
    {
        auto c = assign_interval(cs[i], vars, a.box());
        maximum = std::max(maximum, std::max(abs(c.left()), abs(c.right())));
    }
    const QQ shift = QQ(2) + maximum / m;
    std::cerr<<"XZ-BOUND call="<<call<<" leading="<<leading<<" m="<<m<<" M="<<maximum<<" shift="<<shift<<std::endl;
    used_shift = shift;
    const auto q = [&](){cad_diag::Scope d("TRANSLATE");return translate(f,v,-shift);}();
    std::cerr<<"XZ-TRANSLATED call="<<call<<" terms="<<q.size()<<std::endl;
    {std::ofstream file("/private/tmp/clpoly-054-termination-20261022/translated-"+std::to_string(call)+".txt");file<<q<<std::endl;}
    size_t iteration=0;
    QQ epsilon(1);
    while (true)
    {
        ++iteration;
        epsilon /= QQ(2);
        std::cerr<<"XZ-ITERATION call="<<call<<" iteration="<<iteration<<" epsilon="<<epsilon<<std::endl;
        auto b = [&](){cad_diag::Scope d("BOUNDS");return bounds(q,v,vars,a.box());}();
        cad_diag::uinfo("  LOWER",b.first);cad_diag::uinfo("  UPPER",b.second);
        {std::ofstream file("/private/tmp/clpoly-054-termination-20261022/bounds-"+std::to_string(call)+"-"+std::to_string(iteration)+".txt");
        file<<"LOWER ascending coefficients:\n";for(size_t k=0;k<b.first.size();++k)file<<k<<": "<<b.first[k]<<"\n";
        file<<"UPPER ascending coefficients:\n";for(size_t k=0;k<b.second.size();++k)file<<k<<": "<<b.second[k]<<"\n";}

        bool accept = b.first.back() != QQ(0) && sgn(b.first.back()) == sgn(b.second.back()) &&
                      squarefree(b.first) && squarefree(b.second);
        std::vector<I> intervals;
        std::cerr<<"  squarefree-check="<<accept<<std::endl;
        if (accept)
        {
            auto l = univariate(b.first, epsilon), u = univariate(b.second, epsilon);
            std::cerr<<"  lower-roots="<<l.size()<<" upper-roots="<<u.size()<<std::endl;
            accept = l.size() == u.size();
            if (accept)
            {
                for (size_t j = 0; j < l.size(); ++j)
                {
                    auto joint = hull(l[j], u[j]);
                    if (joint.left() <= QQ(0) || !certified(b, joint) ||
                        (!intervals.empty() && intervals.back().right() >= joint.left()))
                    {
                        accept = false;
                        break;
                    }
                    intervals.push_back(joint);
                }
            }
        }
        if (accept)
        {
            for (auto &j : intervals)
            {
                j -= I(shift);
            }
            std::cerr<<"XZ-ACCEPT call="<<call<<" roots="<<intervals.size()<<std::endl;
            return intervals;
        }
        if (a.size())
        {
            std::cerr<<"XZ-REFINE call="<<call<<std::endl;
            a.refine(a.max_width() / QQ(2));
        }
    }
}
} // 命名空间 xz_detail

// XZ06 NREALZERO Step 2：只在一个已经认证的前缀上提升最后坐标。
// 前置条件：chain 平方自由正则，prefix 的定义方程是 chain 的低一维前缀。
inline std::vector<real_algebraic_point> __lift_real_points(const triangular_set &chain,
                                                            real_algebraic_point prefix)
{
    assert(chain.is_squarefree());
    assert(chain.size() == prefix.size() + 1);
    assert(std::equal(prefix.chain().variables().begin(), prefix.chain().variables().end(),
                      chain.variables().begin()));
    QQ shift;
    const auto intervals =
        xz_detail::lift(chain.equations().back(), chain.variables().back(), prefix, shift);
    std::vector<real_algebraic_point> points;
    for (const auto &interval : intervals)
    {
        // XZ-LIFT 已认证新层；旧前缀由输入证书保证，不重复验证全部旧层。
        real_algebraic_point point;
        point.chain_ = chain;
        point.box_ = prefix.box();
        point.box_.push_back(interval);
        point.shifts_ = prefix.shifts();
        point.shifts_.push_back(shift);
        points.push_back(std::move(point));
    }
    return points;
}

// PDF 算法 4：对每个既有实前缀逐层调用单前缀提升，得到整条链的全部实点。
inline std::vector<real_algebraic_point> isolate_real_points(const triangular_set &t)
{
    if (!t.is_squarefree())
    {
        throw std::invalid_argument("NREALZERO: nonsquarefree chain");
    }
    std::vector<real_algebraic_point> points(1);
    for (size_t i = 0; i < t.size(); ++i)
    {
        const auto chain = t.prefix(i + 1);
        std::vector<real_algebraic_point> next;
        for (auto &prefix : points)
        {
            auto extensions = __lift_real_points(chain, std::move(prefix));
            for (auto &point : extensions)
            {
                next.push_back(std::move(point));
            }
        }
        points = std::move(next);
    }
    return points;
}
// PDF 算法 5：RSD 标记全部复分支，用区间排除与所选实点不符的分支，
// 直到仅剩一种标签。余式非零本身不能判定某个指定共轭点上的值非零。
template <class C, class Order>
bool point_zero(const polynomial_<C, Order> &f, real_algebraic_point &a)
{
    auto branches = split_zero(a.chain(), f);
    const std::vector<variable> ordered_vars(a.chain().variables().rbegin(),
                                             a.chain().variables().rend());
    std::vector<rational_interval> ordered_box;
    auto eliminate = [&](std::vector<triangular_set> &list)
    {
        list.erase(std::remove_if(
                       list.begin(), list.end(),
                       [&](const triangular_set &t)
                       {
                           for (const auto &g : t.equations())
                           {
                               if (!__assign_interval(g, ordered_vars, ordered_box).contains_zero())
                               {
                                   return true;
                               }
                           }
                           return false;
                       }),
                   list.end());
    };
    while (true)
    {
        ordered_box.assign(a.box().rbegin(), a.box().rend());
        eliminate(branches.zero);
        eliminate(branches.nonzero);
        if (branches.zero.empty() && branches.nonzero.empty())
        {
            throw std::logic_error("POINT-ZERO: lost selected point");
        }
        if (branches.nonzero.empty())
        {
            return true;
        }
        if (branches.zero.empty())
        {
            return false;
        }
        a.refine(a.max_width() / QQ(2));
    }
}
// PDF 算法 6：严格区间符号直接返回；不确定时精确判零，再精化非零点值。
template <class C, class Order>
int point_sign(const polynomial_<C, Order> &f, real_algebraic_point &a)
{
    const auto q = a.chain().convert(f);
    const std::vector<variable> ordered_vars(a.chain().variables().rbegin(),
                                             a.chain().variables().rend());
    auto interval_sign = [&]()
    {
        const std::vector<rational_interval> ordered_box(a.box().rbegin(), a.box().rend());
        return __assign_interval(q, ordered_vars, ordered_box).sgn();
    };
    int sign = interval_sign();
    if (xz_detail::strict_sign(sign))
    {
        return sign;
    }
    if (point_zero(q, a))
    {
        return 0;
    }
    while (true)
    {
        sign = interval_sign();
        if (xz_detail::strict_sign(sign))
        {
            return sign;
        }
        a.refine(a.max_width() / QQ(2));
    }
}

inline bool point_on_chain(const triangular_set &t, real_algebraic_point &a)
{
    if (t.variables() != a.chain().variables())
    {
        throw std::invalid_argument("point membership: different coordinates");
    }
    for (const auto &f : t.equations())
    {
        if (!point_zero(f, a))
        {
            return false;
        }
    }
    return true;
}
inline bool same_real_point(real_algebraic_point a, const real_algebraic_point &b)
{
    if (!point_on_chain(b.chain(), a))
    {
        return false;
    }
    while (true)
    {
        bool inside = true;
        for (size_t j = 0; j < a.size(); ++j)
        {
            if (!a.box()[j].overlaps(b.box()[j]))
            {
                return false;
            }
            if (!b.box()[j].interior_contains(a.box()[j]))
            {
                inside = false;
            }
        }
        if (inside)
        {
            return true;
        }
        a.refine(a.max_width() / QQ(2));
    }
}
// PDF 算法 9：按维数递归重编码同一个实点，不枚举其他实前缀。
inline real_algebraic_point reencode_point(real_algebraic_point a, const triangular_set &chain)
{
    if (chain.variables() == a.chain().variables() && chain.equations() == a.chain().equations())
    {
        return a;
    }
    if (!point_on_chain(chain, a))
    {
        throw std::invalid_argument("REENCODE: point is not on component");
    }
    if (chain.size() == 0)
    {
        return a;
    }
    for (const auto &component : squarefree_decomposition(chain))
    {
        if (!chain.is_squarefree() && !point_on_chain(component, a))
        {
            continue;
        }
        auto prefix = reencode_point(a.prefix(a.size() - 1), component.prefix(a.size() - 1));
        for (auto candidate : __lift_real_points(component, std::move(prefix)))
        {
            if (same_real_point(candidate, a))
            {
                return candidate;
            }
        }
    }
    throw std::logic_error("REENCODE: lost selected point");
}
inline real_algebraic_point append_rational(const real_algebraic_point &a, const variable &v,
                                            const QQ &value)
{
    using P = triangular_set::polynomial_type;
    auto vars = a.chain().variables();
    if (std::find(vars.begin(), vars.end(), v) != vars.end())
    {
        throw std::invalid_argument("append_rational: repeated variable");
    }
    vars.push_back(v);
    triangular_set::order_type order(
        custom_var_order(std::vector<variable>(vars.rbegin(), vars.rend())));
    P linear(&order);
    basic_monomial<triangular_set::order_type> m(&order), one(&order);
    m = {{v, 1}};
    linear.push_back({m, QQ(1)});
    if (value != QQ(0))
    {
        linear.push_back({one, -value});
    }
    auto equations = a.chain().equations();
    equations.push_back(linear);
    auto box = a.box();
    box.emplace_back(value - QQ(1), value + QQ(1));
    auto shifts = a.shifts();
    shifts.push_back(box.back().left() > QQ(0) ? QQ(0) : QQ(1) - box.back().left());
    return real_algebraic_point(triangular_set(std::move(vars), equations), std::move(box),
                                std::move(shifts));
}

// PDF 算法 10：WRSD 选择指定点上的次数分支，平方自由化后仅提升所选实前缀。
template <class C, class Order>
std::vector<real_algebraic_point> roots_over(const polynomial_<C, Order> &input,
                                             real_algebraic_point a, const variable &v)
{
    using namespace xz_detail;
    auto vars = a.chain().variables();
    if (std::find(vars.begin(), vars.end(), v) != vars.end())
    {
        throw std::invalid_argument("ROOTS-QQ: repeated variable");
    }
    vars.push_back(v);
    triangular_set::order_type order(
        custom_var_order(std::vector<variable>(vars.rbegin(), vars.rend())));
    for (const auto &term : input)
    {
        for (const auto &ve : term.first)
        {
            if (ve.second < 0 || std::find(vars.begin(), vars.end(), ve.first) == vars.end())
            {
                throw std::invalid_argument("ROOTS-QQ: undeclared variable");
            }
        }
    }
    P f(&order);
    poly_convert(input, f);
    auto cs = coefficients(f, v);
    auto selected = a.chain();
    int64_t degree_at_point = -1;
    for (size_t j = cs.size(); j-- > 0;)
    {
        auto branches = weak_split_zero(selected, cs[j]);
        bool found = false;
        for (const auto &t : branches.nonzero)
        {
            if (point_on_chain(t, a))
            {
                selected = t;
                degree_at_point = static_cast<int64_t>(j);
                found = true;
                break;
            }
        }
        if (found)
        {
            break;
        }
        for (const auto &t : branches.zero)
        {
            if (point_on_chain(t, a))
            {
                selected = t;
                found = true;
                break;
            }
        }
        if (!found)
        {
            throw std::logic_error("ROOTS-QQ: decomposition lost selected point");
        }
    }
    if (degree_at_point < 0)
    {
        throw std::domain_error("ROOTS-QQ: identically zero specialization");
    }
    if (degree_at_point == 0)
    {
        return {};
    }
    P truncated(&order);
    for (const auto &term : f)
    {
        if (term.first.deg(v) <= degree_at_point)
        {
            truncated.push_back(term);
        }
    }
    auto equations = selected.equations();
    equations.push_back(truncated);
    triangular_set extended(vars, equations);
    std::vector<real_algebraic_point> result;
    for (const auto &t : squarefree_decomposition(extended))
    {
        const auto prefix_chain = t.prefix(a.size());
        if (!point_on_chain(prefix_chain, a))
        {
            continue;
        }
        auto prefix = reencode_point(a, prefix_chain);
        for (auto candidate : __lift_real_points(t, std::move(prefix)))
        {
            bool duplicate = false;
            for (auto &previous : result)
            {
                if (!candidate.box().back().overlaps(previous.box().back()))
                {
                    continue;
                }
                if (same_real_point(candidate, previous))
                {
                    duplicate = true;
                    break;
                }
                // 精化结果保留在根表中；不同分支的互异根最终严格分离。
                while (candidate.box().back().overlaps(previous.box().back()))
                {
                    candidate.refine(candidate.max_width() / QQ(2));
                    previous.refine(previous.max_width() / QQ(2));
                }
            }
            if (!duplicate)
            {
                result.push_back(std::move(candidate));
            }
        }
    }
    // 合并循环已保证末坐标区间两两不相交，比较器只读端点，不求解或复制实点。
    std::sort(result.begin(), result.end(),
              [](const real_algebraic_point &left, const real_algebraic_point &right)
              { return left.box().back().left() < right.box().back().left(); });
    return result;
}
} // 命名空间 clpoly
#endif
