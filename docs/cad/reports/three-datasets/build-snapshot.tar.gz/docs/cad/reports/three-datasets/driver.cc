// 读取实验脚本生成的精确系数文件，不在此处解释题意或进行预处理。
#include <clpoly/full_cad.hh>
#include <chrono>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace clpoly;
using P = polynomial_QQ;

struct atom
{
    size_t polynomial;
    char relation;
};

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        return 2;
    }
    try
    {
        std::ifstream input(argv[1]);
        size_t variable_count, polynomial_count, clause_count;
        input >> variable_count >> polynomial_count >> clause_count;
        std::vector<variable> variables;
        for (size_t i = 0; i < variable_count; ++i)
        {
            std::string name;
            input >> name;
            variables.emplace_back(name);
        }
        std::vector<P> polynomials;
        for (size_t i = 0; i < polynomial_count; ++i)
        {
            size_t term_count;
            input >> term_count;
            P p;
            for (size_t j = 0; j < term_count; ++j)
            {
                std::string numerator, denominator;
                input >> numerator >> denominator;
                P term{QQ(ZZ(numerator), ZZ(denominator))};
                for (const auto &v : variables)
                {
                    unsigned int exponent;
                    input >> exponent;
                    if (exponent)
                    {
                        term = term * pow(v, exponent);
                    }
                }
                p = p + term;
            }
            polynomials.push_back(std::move(p));
        }
        std::vector<std::vector<atom>> clauses(clause_count);
        for (auto &clause : clauses)
        {
            size_t count;
            input >> count;
            for (size_t i = 0; i < count; ++i)
            {
                atom a;
                input >> a.polynomial >> a.relation;
                clause.push_back(a);
            }
        }
        if (!input)
        {
            throw std::runtime_error("invalid experiment input");
        }
        if (argc > 2)
        {
            std::reverse(variables.begin(), variables.end());
        }

        const auto start = std::chrono::steady_clock::now();
        auto cad = full_cad(polynomials, variables);
        const auto built = std::chrono::steady_clock::now();
        size_t feasible = 0, first = SIZE_MAX;
        for (size_t i = 0; i < cad.leaf_count(); ++i)
        {
            bool satisfied = true;
            for (const auto &clause : clauses)
            {
                bool any = false;
                for (const auto &a : clause)
                {
                    const int s = cad.signs(i)[a.polynomial];
                    any = any || (a.relation == '=' ? s == 0 : a.relation == '>' ? s > 0 : s < 0);
                }
                satisfied = satisfied && any;
            }
            if (satisfied)
            {
                ++feasible;
                if (first == SIZE_MAX)
                {
                    first = i;
                }
            }
        }
        if (first != SIZE_MAX)
        {
            // 独立调用普通点查询，核对已选 SAT 样本的每个输入符号。
            auto sample = cad.leaf_sample(first);
            for (size_t i = 0; i < polynomials.size(); ++i)
            {
                if (point_sign(polynomials[i], sample) != cad.signs(first)[i])
                {
                    throw std::runtime_error("SAT sample sign mismatch");
                }
            }
        }
        const auto end = std::chrono::steady_clock::now();
        std::cout << "status=" << (feasible ? "sat" : "unsat")
                  << " leaves=" << cad.leaf_count() << " feasible=" << feasible
                  << " cad_seconds=" << std::chrono::duration<double>(built - start).count()
                  << " total_seconds=" << std::chrono::duration<double>(end - start).count()
                  << std::endl;
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << std::endl;
        return 1;
    }
}
