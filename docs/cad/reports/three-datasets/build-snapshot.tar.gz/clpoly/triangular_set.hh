/** 独立 QQ 三角列，分解复用 XY16 算法 2.1、2.2 和 3.1。
 * 不依赖区间、实点或 CAD。规格见 docs/cad/design/modular-cad/triangular-set.md。
 */
#ifndef CLPOLY_TRIANGULAR_SET_HH
#define CLPOLY_TRIANGULAR_SET_HH
#include <clpoly/polynomial.hh>
#include <clpoly/polynomial_gcd.hh>
#include <clpoly/resultant.hh>
#include <clpoly/charset.hh>
#include <clpoly/polynomial_convert.hh>
#include <memory>
#include <set>
#include <stdexcept>
namespace clpoly
{
// 方程使用本对象持有的不可变比较器；复制对象共享其所有权。
// 公开构造检查表示不变量，独立分解函数调用已审核的 charset 算法。
class triangular_set
{
public:
    using order_type = lex_<custom_var_order>;
    using polynomial_type = polynomial_<QQ, order_type>;
    using integer_polynomial = polynomial_<ZZ, order_type>;

private:
    std::shared_ptr<const order_type> order_;
    std::vector<variable> vars_;
    std::vector<polynomial_type> equations_;
    bool squarefree_ = true;
    std::vector<bool> squarefree_prefix_;

public:
    template <class C, class Order>
    triangular_set(std::vector<variable> vars, const std::vector<polynomial_<C, Order>> &equations)
        : order_(std::make_shared<const order_type>(
              custom_var_order(std::vector<variable>(vars.rbegin(), vars.rend())))),
          vars_(std::move(vars))
    {
        if (equations.size() != vars_.size() ||
            std::set<variable>(vars_.begin(), vars_.end()).size() != vars_.size())
        {
            throw std::invalid_argument("triangular_set: invalid coordinate list");
        }
        for (size_t i = 0; i < equations.size(); ++i)
        {
            polynomial_type q(order_.get());
            poly_convert(equations[i], q);
            for (const auto &term : q)
            {
                for (const auto &ve : term.first)
                {
                    if (ve.second < 0 || std::find(vars_.begin(), vars_.begin() + i + 1,
                                                   ve.first) == vars_.begin() + i + 1)
                    {
                        throw std::invalid_argument(
                            "triangular_set: equation uses a later or unbound variable");
                    }
                }
            }
            if (q.empty() || degree(q, vars_[i]) <= 0)
            {
                throw std::invalid_argument("triangular_set: missing main variable");
            }
            equations_.push_back(std::move(q));
        }
        // 逐次结式验证初式在所有复前缀根上非零，判别式另用于检查平方自由性。
        // 保存每个前缀的累计结果，供已认证对象的 prefix 查询复用。
        const auto z = integer_equations();
        for (size_t i = 0; i < z.size(); ++i)
        {
            auto initial = leadcoeff(z[i]);
            auto discriminant_i = discriminant(z[i], vars_[i]);
            for (size_t j = i; j-- > 0;)
            {
                initial = resultant(initial, z[j], vars_[j]);
                if (!discriminant_i.empty())
                {
                    discriminant_i = resultant(discriminant_i, z[j], vars_[j]);
                }
            }
            if (initial.empty())
            {
                throw std::invalid_argument("triangular_set: nonregular initial");
            }
            if (discriminant_i.empty())
            {
                squarefree_ = false;
            }
            squarefree_prefix_.push_back(squarefree_);
        }
    }
    triangular_set() : triangular_set(std::vector<variable>{}, std::vector<polynomial_type>{}) {}
    size_t size() const
    {
        return vars_.size();
    }
    bool is_squarefree() const
    {
        return squarefree_;
    }
    const std::vector<variable> &variables() const
    {
        return vars_;
    }
    const std::vector<polynomial_type> &equations() const
    {
        return equations_;
    }
    const order_type *order() const
    {
        return order_.get();
    }
    template <class C, class Order>
    // 返回多项式借用本链的比较器，使用时须保持链的所有者存活。
    polynomial_type convert(const polynomial_<C, Order> &f) const
    {
        for (const auto &term : f)
        {
            for (const auto &ve : term.first)
            {
                if (ve.second < 0 || std::find(vars_.begin(), vars_.end(), ve.first) == vars_.end())
                {
                    throw std::invalid_argument("triangular_set: unbound variable");
                }
            }
        }
        polynomial_type q(order_.get());
        poly_convert(f, q);
        return q;
    }
    // 清除正分母；返回的整数方程同样借用 order_。
    std::vector<integer_polynomial> integer_equations() const
    {
        std::vector<integer_polynomial> out;
        for (const auto &f : equations_)
        {
            integer_polynomial z(order_.get());
            poly_convert(f, z);
            out.push_back(std::move(z));
        }
        return out;
    }
    triangular_set prefix(size_t n) const
    {
        if (n > size())
        {
            throw std::out_of_range("triangular_set: prefix length");
        }
        // 正则性和各前缀的平方自由性已在公开构造时验证，不重复计算结式。
        // 前缀仍拥有独立比较器，并将所复制方程重新绑定到该比较器。
        triangular_set result;
        result.vars_.assign(vars_.begin(), vars_.begin() + n);
        result.order_ = std::make_shared<const order_type>(
            custom_var_order(std::vector<variable>(result.vars_.rbegin(), result.vars_.rend())));
        result.squarefree_prefix_.assign(squarefree_prefix_.begin(),
                                         squarefree_prefix_.begin() + n);
        result.squarefree_ = n == 0 || result.squarefree_prefix_.back();
        for (size_t i = 0; i < n; ++i)
        {
            polynomial_type equation(result.order());
            poly_convert(equations_[i], equation);
            result.equations_.push_back(std::move(equation));
        }
        return result;
    }
};
struct triangular_split
{
    std::vector<triangular_set> zero, nonzero;
};
// XY16 算法 2.1/2.2：保留零与非零分支标签。
namespace triangular_detail
{
template <class C, class Order>
triangular_split split_zero_impl(const triangular_set &t, const polynomial_<C, Order> &f, bool weak)
{
    auto q = t.convert(f);
    if (t.size() == 0)
    {
        return q.empty() ? triangular_split{{t}, {}} : triangular_split{{}, {t}};
    }
    triangular_set::integer_polynomial z(t.order());
    poly_convert(q, z);
    const auto branches = weak ? wrsd(t.integer_equations(), z) : rsd(t.integer_equations(), z);
    triangular_split result;
    auto append = [&](const auto &chains, auto &out, bool zero)
    {
        for (const auto &chain : chains)
        {
            auto witness = z;
            for (size_t i = chain.size(); i-- > 0;)
            {
                witness = zero ? prem(witness, chain[i], t.variables()[i])
                               : resultant(witness, chain[i], t.variables()[i]);
            }
            if ((!weak || !zero) && witness.empty() != zero)
            {
                throw std::logic_error("triangular split: branch label violates XY16 contract");
            }
            out.emplace_back(t.variables(), chain);
        }
    };
    append(branches.first, result.zero, true);
    append(branches.second, result.nonzero, false);
    if (result.zero.empty() && result.nonzero.empty())
    {
        throw std::logic_error("RSD: lost every component");
    }
    return result;
}
} // 命名空间 triangular_detail
template <class C, class Order>
triangular_split split_zero(const triangular_set &t, const polynomial_<C, Order> &f)
{
    return triangular_detail::split_zero_impl(t, f, false);
}
template <class C, class Order>
triangular_split weak_split_zero(const triangular_set &t, const polynomial_<C, Order> &f)
{
    return triangular_detail::split_zero_impl(t, f, true);
}
// XY16 算法 3.1：包装器检查输出链正则且平方自由。
inline std::vector<triangular_set> squarefree_decomposition(const triangular_set &t)
{
    if (t.size() == 0 || t.is_squarefree())
    {
        return {t};
    }
    std::vector<triangular_set> out;
    for (const auto &chain : RCtoSqrfree(t.integer_equations()))
    {
        out.emplace_back(t.variables(), chain);
        if (!out.back().is_squarefree())
        {
            throw std::logic_error("RCtoSqrfree: non-squarefree output");
        }
    }
    if (out.empty())
    {
        throw std::logic_error("RCtoSqrfree: lost every component");
    }
    return out;
}
} // 命名空间 clpoly
#endif
