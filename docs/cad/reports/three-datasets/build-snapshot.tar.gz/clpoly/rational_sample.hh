/** 开区间的最简有理数采样，仅依赖 ZZ/QQ。
 * 规格、连分数伪代码与证明：docs/cad/design/rational-sampling.md。
 */
#ifndef CLPOLY_RATIONAL_SAMPLE_HH
#define CLPOLY_RATIONAL_SAMPLE_HH
#include <clpoly/number/QQ.hh>
#include <optional>
#include <stdexcept>
#include <vector>

namespace clpoly
{
namespace rational_sample_detail
{
inline ZZ floor(const QQ &q)
{
    ZZ result;
    ZZ::fdiv_q(result, q.num(), q.den());
    return result;
}

// POSITIVE：要求 0 <= left < right，两个端点都不包含。
// 保存整数部分并逆序恢复，避免长连分数耗尽递归调用栈。
inline QQ positive(QQ left, QQ right)
{
    std::vector<ZZ> parts;
    QQ result;
    while (true)
    {
        const ZZ k = floor(left);
        result = QQ(k + ZZ(1));
        if (result < right)
        {
            break;
        }

        // 没有整数内点，变换 x -> 1/(x-k)，同时交换上下界。
        parts.push_back(k);
        const QQ fraction = left - QQ(k);
        left = QQ(1) / (right - QQ(k));
        if (fraction.is_zero())
        {
            // 旧下界恰为整数，新上界为正无穷；不实际计算 1/0。
            result = QQ(floor(left) + ZZ(1));
            break;
        }
        right = QQ(1) / fraction;
    }
    for (auto it = parts.rbegin(); it != parts.rend(); ++it)
    {
        result = QQ(*it) + QQ(1) / result;
    }
    return result;
}
} // namespace rational_sample_detail

// SAMPLE-RATIONAL：分母最小，同分母时分子绝对值最小。
// 只接受非空开区间；相等端点也拒绝，不能当成闭区间单点。
inline QQ sample_rational(const QQ &left, const QQ &right)
{
    if (!(left < right))
    {
        throw std::invalid_argument("sample_rational: empty or reversed open interval");
    }
    if (left.num().sgn() < 0 && right.num().sgn() > 0)
    {
        return QQ(0);
    }
    if (right.num().sgn() <= 0)
    {
        return -rational_sample_detail::positive(-right, -left);
    }
    return rational_sample_detail::positive(left, right);
}

// 缺失左/右端点分别表示负/正无穷；存在的端点始终排除。
inline QQ sample_rational(const std::optional<QQ> &left, const std::optional<QQ> &right)
{
    if (left && right)
    {
        return sample_rational(*left, *right);
    }
    if (!left && !right)
    {
        return QQ(0);
    }
    if (!left)
    {
        if (right->num().sgn() > 0)
        {
            return QQ(0);
        }
        return QQ(-rational_sample_detail::floor(-*right) - ZZ(1));
    }
    if (left->num().sgn() < 0)
    {
        return QQ(0);
    }
    return QQ(rational_sample_detail::floor(*left) + ZZ(1));
}
} // namespace clpoly
#endif
