#include <cad_diag.hh>
/** 基于 QQ 代表与 XZ06 三角列实点的完整 Lazard CAD。
 * 投影和树存储复用已审核实现，算术由 lazard_qq.hh 提供。
 * 对应 PDF 算法 12（LIFT-STACK）、13（FULL-CAD）。
 */
#ifndef CLPOLY_FULL_CAD_HH
#define CLPOLY_FULL_CAD_HH
#include <clpoly/cad.hh>
#include <clpoly/full_cad_result.hh>
#include <clpoly/lazard_qq.hh>
#include <clpoly/rational_sample.hh>
namespace clpoly
{
template <class C, class Order>
lazard_evaluation_result lazard_evaluate(const polynomial_<C, Order> &f,
                                         const std::vector<variable> &vars, const cad_sample &a)
{
    return lazard_evaluate_qq(f, vars, a);
}
// PDF 算法 12（LIFT-STACK）：alpha 是父样本，所有求值均相对于该点解释，
// 父节点按存储顺序访问。根证书描述样本纤维上的根，来源身份引用投影定理
// 所保证的有序连续根函数。
inline void lift_stack(full_cad_result &result, size_t level, size_t parent,
                       const cad_sample &alpha,
                       const std::vector<lazard_evaluation_result> &evaluations)
{
    using P = triangular_set::polynomial_type;
    // 在 alpha 上专门化与 QQ 乘积交换；乘积的不同根就是全部因子根的并，
    // 其中共享根只保留一次。
    P product(result.order());
    product.push_back({basic_monomial<full_cad_result::order_type>(result.order()), QQ(1)});
    for (const auto &e : evaluations)
    {
        P p(result.order());
        poly_convert(e.polynomial, p);
        product = product * p;
    }
    cad_stack st;
    st.evaluations = evaluations;
    std::cerr<<"PRODUCT level="<<level<<" degree="<<degree(product,result.level_var(level))<<" terms="<<product.size()<<" polynomial="<<product<<std::endl;
    st.roots = roots_over(product, alpha, result.level_var(level));
    std::cerr<<"ROOTS count="<<st.roots.size()<<std::endl;
    for(auto &r:st.roots)std::cerr<<"  root-box="<<r.box().back()<<std::endl;
    // 每个来源分别计算不同根序号，共享根对所有相关来源都计数。
    // 选第一个来源作为规范身份，保持既有 cad_root(poly_idx,root_idx) 的含义。
    std::vector<size_t> root_counts(evaluations.size(), 0);
    std::vector<cad_root> boundaries;
    for (auto &root : st.roots)
    {
        std::vector<size_t> sources;
        for (size_t j = 0; j < evaluations.size(); ++j)
        {
            if (point_zero(evaluations[j].polynomial, root))
            {
                sources.push_back(j);
            }
        }
        if (sources.empty())
        {
            throw std::logic_error("CAD: root without defining source");
        }
        const size_t source = sources.front();
        boundaries.emplace_back(source, root_counts[source]);
        for (size_t index : sources)
        {
            ++root_counts[index];
        }
        st.sources.push_back(std::move(sources));
    }
    const size_t dim = level ? result.dimension(level - 1, parent) : 0;
    // 子节点按 Sector、Section、…、Sector 连续存储。
    // 无根时生成一个圆柱胞腔，样本取零；其余 Sector 在认证的 QQ
    // 开间隙中选择最简有理数，不改变 Section 的根证书。
    for (size_t i = 0; i <= st.roots.size(); ++i)
    {
        QQ q(0);
        if (!st.roots.empty())
        {
            if (i == 0)
            {
                q = sample_rational(std::nullopt, st.roots.front().box().back().left());
            }
            else if (i == st.roots.size())
            {
                q = sample_rational(st.roots.back().box().back().right(), std::nullopt);
            }
            else
            {
                while (st.roots[i - 1].box().back().right() >= st.roots[i].box().back().left())
                {
                    st.roots[i - 1].shrink();
                    st.roots[i].shrink();
                }
                q = sample_rational(st.roots[i - 1].box().back().right(),
                                    st.roots[i].box().back().left());
            }
        }
        auto left = i ? boundaries[i - 1] : cad_root::neginf();
        auto right = i < st.roots.size() ? boundaries[i] : cad_root::inf();
        result.add_sector(level, parent, left, right, q,
                          append_rational(alpha, result.level_var(level), q), dim + 1);
        if (i < st.roots.size())
        {
            result.add_section(level, parent, boundaries[i], st.roots[i], dim);
        }
    }
    result.add_stack(level, std::move(st));
}

// PDF 算法 13（FULL-CAD）：先投影，再逐层提升，最后计算原输入的叶符号。
// 公开变量表采用投影序，提升时反向遍历。
template <class C, class Order>
full_cad_result full_cad(const std::vector<polynomial_<C, Order>> &input,
                         const std::vector<variable> &vars)
{
    const std::set<variable> unique(vars.begin(), vars.end());
    if (unique.size() != vars.size())
    {
        throw std::invalid_argument("full_cad: duplicate variables");
    }
    auto order = std::make_shared<const full_cad_result::order_type>(custom_var_order(vars));
    std::vector<full_cad_result::poly_type> polys;
    std::vector<triangular_set::polynomial_type> originals;
    for (const auto &f : input)
    {
        for (const auto &term : f)
        {
            for (const auto &ve : term.first)
            {
                if (ve.second < 0 || !unique.count(ve.first))
                {
                    throw std::invalid_argument("full_cad: undeclared variable");
                }
            }
        }
        full_cad_result::poly_type p(order.get());
        poly_convert(f, p);
        polys.push_back(std::move(p));
        triangular_set::polynomial_type q(order.get());
        poly_convert(f, q);
        originals.push_back(std::move(q));
    }
    // 使用已审核的 Lazard/FACTOR 投影契约，见 PDF 第 9 节。
    auto projection = [&](){cad_diag::Scope s("PROJECT");return __project_full(polys,vars,projection_method::LAZARD,basis_computation_method::FACTOR);}();
    for(size_t k=0;k<projection.size();++k) {
        std::cerr<<"PROJECTION variable="<<vars[k]<<" count="<<projection[k].size()<<std::endl;
        for(size_t i=0;i<projection[k].size();++i)std::cerr<<"  P["<<i<<"]="<<projection[k][i]<<std::endl;
    }
    // 多项式借用比较器指针，统一重新绑定到结果所持有的比较器。
    for (auto &layer : projection)
    {
        for (auto &p : layer)
        {
            full_cad_result::poly_type q(order.get());
            poly_convert(p, q);
            p = std::move(q);
        }
    }
    full_cad_result result(order, vars, std::move(projection));
    std::vector<variable> lifting(vars.rbegin(), vars.rend());
    for (size_t level = 0; level < vars.size(); ++level)
    {
        std::vector<variable> prefix(lifting.begin(), lifting.begin() + level + 1);
        const size_t parents = level ? result.level_size(level - 1) : 1;
        std::cerr<<"LAYER level="<<level<<" variable="<<lifting[level]<<" parents="<<parents<<std::endl;
        for (size_t j = 0; j < parents; ++j)
        {
            cad_diag::set("level",level);cad_diag::set("parent",j);
            auto a = level ? result.sample(level - 1, j) : cad_sample{};
            std::cerr<<"PARENT level="<<level<<" index="<<j<<std::endl;
            for(size_t i=0;i<a.size();++i)std::cerr<<"  chain="<<a.chain().equations()[i]<<" box="<<a.box()[i]<<std::endl;
            std::vector<lazard_evaluation_result> gs;
            for (const auto &f : result.level_polys(level))
            {
                gs.push_back(lazard_evaluate(f, prefix, a));
            }
            for(size_t i=0;i<gs.size();++i) {std::cerr<<"  LAZARD["<<i<<"]="<<gs[i].polynomial<<" valuation=";for(auto n:gs[i].valuation)std::cerr<<n<<",";std::cerr<<std::endl;}
            lift_stack(result, level, level ? j : SIZE_MAX, a, gs);
            std::cerr<<"PARENT-DONE level="<<level<<" index="<<j<<std::endl;
        }
    }
    // 因子归一化不保证保留原符号，因此叶符号从原 QQ 输入计算。
    std::vector<std::vector<int>> signs;
    for (size_t j = 0; j < result.leaf_count(); ++j)
    {
        auto a = result.leaf_sample(j);
        std::vector<int> row;
        for (const auto &f : originals)
        {
            row.push_back(point_sign(f, a));
        }
        signs.push_back(std::move(row));
    }
    result.set_signs(std::move(signs));
    return result;
}
} // 命名空间 clpoly
#endif
