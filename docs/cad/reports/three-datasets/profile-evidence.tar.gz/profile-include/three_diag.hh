#pragma once
#include <chrono>
#include <iostream>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
namespace three_diag {
using Clock=std::chrono::steady_clock;
struct Frame { std::string name; Clock::time_point start; };
struct Metric { size_t calls=0; double seconds=0; };
inline std::mutex mutex;
inline std::vector<Frame> stack;
inline std::map<std::string,Metric> metrics;
inline std::map<std::string,std::string> context;
struct Scope {
 const char *name; Clock::time_point start=Clock::now();
 Scope(const char *n):name(n) { std::lock_guard<std::mutex> lock(mutex);stack.push_back({name,start});++metrics[name].calls; }
 ~Scope() { auto now=Clock::now();std::lock_guard<std::mutex> lock(mutex);metrics[name].seconds+=std::chrono::duration<double>(now-start).count();stack.pop_back(); }
};
template<class T> void set(const char *key,const T &v) { std::ostringstream s;s<<v;std::lock_guard<std::mutex> lock(mutex);context[key]=s.str(); }
template<class Poly> size_t bits(const Poly &p) {size_t n=0;for(const auto &t:p)n=std::max(n,t.second.sizeinbase(2));return n;}
template<class U> size_t ubits(const U &p) {size_t n=0;for(const auto &q:p)n=std::max(n,std::max(q.num().sizeinbase(2),q.den().sizeinbase(2)));return n;}
inline void dump() {
 auto now=Clock::now();std::lock_guard<std::mutex> lock(mutex);
 std::cerr<<"PATH";for(auto &f:stack)std::cerr<<" "<<f.name<<":"<<std::chrono::duration<double>(now-f.start).count();std::cerr<<"\n";
 std::cerr<<"METRICS";for(auto &[k,v]:metrics)std::cerr<<" "<<k<<":"<<v.calls<<":"<<v.seconds;std::cerr<<"\n";
 std::cerr<<"CONTEXT";for(auto &[k,v]:context)std::cerr<<" "<<k<<":"<<v;std::cerr<<std::endl;
}
inline bool start=[](){std::thread([](){for(;;){std::this_thread::sleep_for(std::chrono::seconds(1));dump();}}).detach();return true;}();
}
