#pragma once
#include <chrono>
#include <fstream>
#include <iostream>
#include <map>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
namespace cad_diag {
using Clock=std::chrono::steady_clock;
struct Frame { std::string name; Clock::time_point start; };
struct Metric { unsigned long calls=0; double seconds=0; };
inline std::mutex mutex;
inline std::vector<Frame> stack;
inline std::map<std::string,Metric> metrics;
inline std::map<std::string,std::string> context;
inline std::map<std::string,unsigned long> ticks;
struct Scope {
 const char *name; Clock::time_point start=Clock::now();
 Scope(const char *n):name(n) { std::lock_guard<std::mutex> lock(mutex); stack.push_back({name,start}); ++metrics[name].calls; }
 ~Scope() { auto now=Clock::now(); std::lock_guard<std::mutex> lock(mutex); metrics[name].seconds+=std::chrono::duration<double>(now-start).count(); stack.pop_back(); }
};
template<class T> void set(const char *key,const T &v) { std::ostringstream s;s<<v;std::lock_guard<std::mutex> lock(mutex);context[key]=s.str(); }
inline void tick(const char *key) { std::lock_guard<std::mutex> lock(mutex);++ticks[key]; }
inline void dump() {
 auto now=Clock::now(); std::lock_guard<std::mutex> lock(mutex);
 std::cerr<<"DIAG path="; for(auto &f:stack) std::cerr<<f.name<<"("<<std::chrono::duration<double>(now-f.start).count()<<"s)/";
 std::cerr<<"\n context:";for(auto &[k,v]:context)std::cerr<<" "<<k<<"="<<v;
 std::cerr<<"\n metrics:";for(auto &[k,v]:metrics)std::cerr<<" "<<k<<"="<<v.calls<<","<<v.seconds<<"s";
 std::cerr<<"\n ticks:";for(auto &[k,v]:ticks)std::cerr<<" "<<k<<"="<<v;std::cerr<<std::endl;
}
template<class Poly> size_t max_bits(const Poly &p) {size_t n=0;for(const auto &t:p)n=std::max(n,t.second.sizeinbase(2));return n;}
template<class Poly> void show(const char *label,const Poly &p) {std::cerr<<label<<p<<std::endl;}
template<class U> void uinfo(const char *label,const U &f) {size_t bits=0;for(const auto &q:f)bits=std::max(bits,std::max(q.num().sizeinbase(2),q.den().sizeinbase(2)));std::cerr<<label<<" degree="<<(f.empty()?0:f.size()-1)<<" coefficient_bits="<<bits<<std::endl;}
inline bool start=[](){std::thread([](){for(;;){std::this_thread::sleep_for(std::chrono::seconds(1));dump();}}).detach();return true;}();
}
