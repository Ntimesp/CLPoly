/** 完整 CAD 的数据容器，沿用 open_cad/cad_tree 的职责划分。
 * 只提供存储与查询，投影、提升、根隔离及样本选择在算法头中实现。
 * 根边界沿用 cad_root 的来源多项式索引与该来源的不同根序号。
 */
#ifndef CLPOLY_FULL_CAD_RESULT_HH
#define CLPOLY_FULL_CAD_RESULT_HH
#include <clpoly/cad_tree.hh>
#include <clpoly/real_algebraic.hh>
#include <clpoly/lazard_qq_result.hh>
#include <algorithm>
namespace clpoly
{
using cad_sample = real_algebraic_point;
using lazard_evaluation_result = lazard_qq_result;
struct cad_stack
{
    std::vector<real_algebraic_point> roots; // 完整前缀及新增根坐标。
    std::vector<lazard_evaluation_result> evaluations;
    std::vector<std::vector<size_t>> sources;
};
class full_cad_result
{
public:
    using order_type = lex_<custom_var_order>;
    using poly_type = polynomial_<ZZ, order_type>;

private:
    std::shared_ptr<const order_type> order_;
    cad_tree<custom_var_order> tree_;
    std::vector<std::vector<cad_sample>> samples_;
    std::vector<std::vector<cad_stack>> stacks_;
    std::vector<std::vector<size_t>> dimensions_;
    std::vector<std::vector<int>> leaf_signs_;

public:
    full_cad_result(std::shared_ptr<const order_type> order, std::vector<variable> vars,
                    std::vector<std::vector<poly_type>> projection)
        : order_(std::move(order)), tree_(std::move(vars), std::move(projection)),
          samples_(tree_.num_levels()), stacks_(tree_.num_levels()), dimensions_(tree_.num_levels())
    {
    }
    size_t num_levels() const
    {
        return tree_.num_levels();
    }
    size_t level_size(size_t k) const
    {
        return tree_.level_size(k);
    }
    size_t leaf_count() const
    {
        return num_levels() ? level_size(num_levels() - 1) : 1;
    }
    const cad_node &node(size_t level, size_t index) const
    {
        return tree_.node(level, index);
    }
    const cad_sample &sample(size_t level, size_t index) const
    {
        return samples_.at(level).at(index);
    }
    const cad_sample &leaf_sample(size_t leaf) const
    {
        if (leaf >= leaf_count())
        {
            throw std::out_of_range("CAD leaf sample index");
        }
        if (num_levels())
        {
            return sample(num_levels() - 1, leaf);
        }
        static const cad_sample empty;
        return empty;
    }
    const cad_stack &stack(size_t level, size_t parent = SIZE_MAX) const
    {
        return stacks_.at(level).at(level ? parent : 0);
    }
    // 在指定父栈解析来源身份；共享根的任何有效来源身份都指向同一个实点。
    const cad_sample &root(size_t level, size_t parent, const cad_root &reference) const
    {
        if (!reference.isfinite())
        {
            throw std::invalid_argument("CAD: infinite boundary has no root sample");
        }
        const auto &current = stack(level, parent);
        size_t ordinal = 0;
        for (size_t i = 0; i < current.roots.size(); ++i)
        {
            const auto &sources = current.sources[i];
            if (std::find(sources.begin(), sources.end(), reference.poly_idx()) != sources.end())
            {
                if (ordinal == reference.root_idx())
                {
                    return current.roots[i];
                }
                ++ordinal;
            }
        }
        throw std::out_of_range("CAD: root reference is not in this parent stack");
    }
    size_t dimension(size_t level, size_t index) const
    {
        return dimensions_.at(level).at(index);
    }
    const std::vector<int> &signs(size_t leaf) const
    {
        return leaf_signs_.at(leaf);
    }
    const auto &level_polys(size_t level) const
    {
        return tree_.level_polys(level);
    }
    const variable &level_var(size_t level) const
    {
        return tree_.level_var(level);
    }
    const cad_tree<custom_var_order> &structure() const
    {
        return tree_;
    }
    void set_signs(std::vector<std::vector<int>> signs)
    {
        leaf_signs_ = std::move(signs);
    }
    // 存储操作保持树、样本及维数表的下标一致。
    // 提升算法负责提供已经计算完成的样本和维数。
    const order_type *order() const
    {
        return order_.get();
    }
    void add_sector(size_t level, size_t parent, cad_root left, cad_root right, const QQ &q,
                    cad_sample sample, size_t dimension)
    {
        tree_.add_sector(level, parent, left, right, q);
        samples_[level].push_back(std::move(sample));
        dimensions_[level].push_back(dimension);
    }
    void add_section(size_t level, size_t parent, cad_root root, cad_sample sample,
                     size_t dimension)
    {
        tree_.add_section(level, parent, root);
        samples_[level].push_back(std::move(sample));
        dimensions_[level].push_back(dimension);
    }
    // 按父节点存储顺序追加，第零层只有一个虚拟父节点。
    void add_stack(size_t level, cad_stack stack)
    {
        stacks_.at(level).push_back(std::move(stack));
    }
};
} // 命名空间 clpoly
#endif
