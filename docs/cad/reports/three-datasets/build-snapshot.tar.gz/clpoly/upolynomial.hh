/**
 * @file upolynomial.hh
 * @author 李昊坤 (ker@pm.me)
 * @brief 定义upolynomial
*/
#ifndef CLPOLY_UPOLYNOMIAL_HH
#define CLPOLY_UPOLYNOMIAL_HH
#include <clpoly/polynomial.hh>
namespace clpoly{
    class umonomial
    {
        private:
            int64_t __deg;
        public:
            umonomial():__deg(0){}
            umonomial(int64_t d):__deg(d){}
            constexpr int64_t deg() const {return this->__deg;}
            constexpr int64_t & deg() {return this->__deg;}
            constexpr bool empty() const  {return __deg==0;}
            constexpr operator int64_t () const{return this->__deg;}
            friend inline umonomial operator*  (umonomial p1,umonomial p2)
            {
                return umonomial(p1.deg()+p2.deg());
            }
            friend inline umonomial operator/  (umonomial p1,umonomial p2)
            {
                return umonomial(p1.deg()-p2.deg());
            }       
            std::string str() const
            {
                std::ostringstream ss;
                ss<<(*this);
                return ss.str();
            }
            friend inline std::ostream& operator<<  (std::ostream& stream, umonomial v) {
                if (!v)
                {
                    stream<<"1";
                }
                else
                {
                    stream<<"#";
                    if (v.deg()!=1)
                        stream<<"^"<<v.deg();
                }
                return stream;
            }
    };
    inline umonomial pow(umonomial m,int64_t i)
    {return umonomial(m.deg()*i);}
    struct uless
    {
        static uless init;
        constexpr bool operator()(const variable & v1,const variable & v2) const 
        {
            return  v1<v2; 
        }
        constexpr bool operator()(const umonomial & v1,const umonomial & v2) const 
        {
            return  v1.deg()>v2.deg(); 
        }
        constexpr bool operator==( uless g1)const {return true;}
        constexpr bool operator!=(uless g1)const {return false;}
    };
    // uless uless::init;
    template <class coeff>
    using upolynomial_=basic_polynomial<umonomial,coeff,uless>;
    using upolynomial_ZZ=upolynomial_<ZZ>;
    inline bool is_divexact(umonomial & op,const umonomial & op1,const umonomial & op2)
    {
        op=umonomial(op1.deg()-op2.deg());
        return op.deg()>=0;    
    }
    template<class Tc>
    Tc assign(const upolynomial_<Tc> &P,const Tc & a)
    {
        Tc O=a-a;
        for (auto &i:P)
        {
            O+=i.second*pow(a,i.first.deg());
        }
        return O;
    }
    template<class Tc,class Tc2,class Tc3>
    Tc assign(const upolynomial_<Tc2> &P,const Tc3 & a)
    {
        Tc O=0;
        for (auto &i:P)
        {
            O+=i.second*pow(a,i.first.deg());
        }
        return O;
    }
    template<class Tc>
    inline int64_t get_deg(const upolynomial_<Tc> &p)
    {
        return p.empty()?0:p.front().first.deg();
    }
    template <class Tc>
    int64_t degree(const upolynomial_<Tc> & p)
    {
        return p.degree();
    }
    inline upolynomial_<Zp> polynomial_mod(const upolynomial_<ZZ> & p, uint64_t prime)
    {
        upolynomial_<Zp> new_p;
        Zp coeff(prime);
        for (auto & i:p)
        {
            coeff=i.second; 
            if (coeff)
            new_p.push_back({i.first,std::move(coeff)});
        }
        return new_p;
    }
    inline void poly_convert(const upolynomial_<Zp>& p_in, upolynomial_<ZZ>& p_out)
    {
        p_out.clear();
        p_out.reserve(p_in.size());
        for (auto& term : p_in)
            p_out.push_back({term.first, ZZ((unsigned long long)term.second.number())});
        p_out.normalization();
    }
    template<class T1,class T2,class comp1>
    void poly_convert(const polynomial_<T1,comp1>& p_in,upolynomial_<T2> & p_out)
    {
        // std::cout<<"poly_convert(const polynomial_<T1,comp1>& p_in,upolynomial_<T2> & p_out)"<<std::endl;
        // std::cout<<p_in<<std::endl;
        // std::cout<<p_out<<std::endl;
        
        p_out.clear();
        p_out.reserve(p_in.size());
        for(auto &i:p_in)
        {
            // std::cout<<i.first.deg()<<" "<<i.second<<std::endl;
        
            p_out.push_back(std::pair<umonomial,T2>(i.first.deg(),i.second));
            // std::cout<<p_out.back().first.deg()<<" "<<p_out.back().second<<std::endl;
        
        }
        // std::cout<<p_out<<std::endl;
        
        // std::cout<<"p_out:"<<p_out<<std::end;
        p_out.normalization();
    }
    template<class T, class comp>
    void poly_convert(const upolynomial_<T>& p_in, polynomial_<T,comp>& p_out, const variable& var)
    {
        p_out.clear();
        p_out.reserve(p_in.size());
        basic_monomial<comp> m(p_out.comp_ptr());
        for (auto& term : p_in)
        {
            m.clear();
            if (term.first.deg() > 0)
                m.push_back({var, term.first.deg()});
            p_out.push_back({m, term.second});
        }
    }

    void poly_convert(const upolynomial_<ZZ>& p_in,upolynomial_<QQ> & p_out);
    void poly_convert(const upolynomial_<QQ>& p_in,upolynomial_<ZZ> & p_out);

    // 单变量伪余式: lc(G)^k * F ≡ R (mod G), k = max(deg(F)-deg(G)+1, 0)
    // 桥接 upolynomial_<ZZ> → polynomial_ → prem → upolynomial_<ZZ>
    // 后续可模板化 prem 直接支持 upolynomial, 届时替换此函数
    inline void upoly_prem(
        upolynomial_<ZZ>& R,
        const upolynomial_<ZZ>& F,
        const upolynomial_<ZZ>& G,
        const variable& var,
        bool is_L = true)
    {
        using Poly = polynomial_<ZZ, univariate_priority_order>;
        univariate_priority_order comp(var);
        Poly F_poly(&comp), G_poly(&comp), R_poly(&comp);
        poly_convert(F, F_poly, var);
        poly_convert(G, G_poly, var);
        prem(R_poly, F_poly, G_poly, var, is_L);
        poly_convert(R_poly, R);
    }

    template <class T>
    upolynomial_<T>  derivative(const upolynomial_<T> & p)
    {
        upolynomial_<T> Pout;
        for (auto &i:p)
        {
            if (i.first.deg())
            {
                T c = i.second * i.first.deg();
                if (!zore_check<T>()(c))
                    Pout.push_back(std::make_pair(umonomial(i.first.deg()-1), c));
            }
        }
        return Pout;
    }
    template <class Tc>
    constexpr bool is_number(const upolynomial_<Tc> & F)
    {
        return (F.empty() || F.size()==1 && F.front().first.empty());
    }
    // 标量乘法：upolynomial * scalar
    template<class Tc>
    upolynomial_<Tc> operator*(upolynomial_<Tc> O, const Tc& c) {
        if (!c) return upolynomial_<Tc>();
        for (auto& i : O)
            i.second *= c;
        O.normalization();
        return O;
    }

    // 标量乘法：scalar * upolynomial
    template<class Tc>
    upolynomial_<Tc> operator*(const Tc& c, upolynomial_<Tc> O) {
        return O * c;
    }

    template <class Tc>
    Tc cont(const upolynomial_<Tc> & F)
    {
        // issue #17 修复：与 polynomial_gcd.hh:1067 (ZZ 特化版) 行为一致
        // 始终非负 + 零多项式约定返 1
        Tc c = 0;
        for (auto &t : F)
        {
            c = gcd(c, t.second);
        }
        if (c == 0)
            return 1;
        return c;
    }
    


}
#endif