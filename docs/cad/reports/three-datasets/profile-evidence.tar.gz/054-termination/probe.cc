#include <clpoly/full_cad.hh>
#include <iostream>
using namespace clpoly;
int main()
{
    variable y("y"), z("z");
    triangular_set::order_type order(custom_var_order({y,z}));
    xz_detail::P f(&order);
    const polynomial_ZZ input = polynomial_ZZ(y)
        * (pow(y,3)*z + 2*pow(y,2)*pow(z,2) + y*pow(z,3) + 4)
        * (y+z) * (pow(y,2)+y*z-2)
        * (pow(y,2)*z+y*pow(z,2)+y-z);
    poly_convert(input,f);
    const auto exact=xz_detail::bounds(f,y,{z},{rational_interval(QQ(-3))}).first;
    auto integer=xz_detail::integer(exact);
    auto g=polynomial_GCD(integer,derivative(integer));
    std::cerr << "EXACT degree=" << get_deg(integer) << " gcd_degree=" << get_deg(g) << std::endl;
    auto prefix=append_rational(cad_sample{},z,QQ(-3));
    QQ shift;
    auto roots=xz_detail::lift(f,y,prefix,shift);
    std::cerr << "DONE roots=" << roots.size() << " shift=" << shift << std::endl;
    for (const auto &r:roots) std::cerr << "ROOT " << r << std::endl;
    return roots.size()==9 ? 0 : 1;
}
