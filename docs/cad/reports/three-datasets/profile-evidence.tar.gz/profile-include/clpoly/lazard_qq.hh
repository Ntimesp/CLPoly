/** 保留冻结变量的 QQ Lazard 求值，对应 PDF 算法 7、8。 */
#ifndef CLPOLY_LAZARD_QQ_HH
#define CLPOLY_LAZARD_QQ_HH
#include <clpoly/real_algebraic.hh>
#include <clpoly/lazard_qq_result.hh>
#include <map>
namespace clpoly
{
// PDF 算法 7：按完整的活动单项式分组，合并得到冻结变量的 QQ 系数多项式，
// 再在指定前缀点上判零。
template <class C, class Order>
bool prefix_zero(const polynomial_<C, Order> &p, real_algebraic_point &prefix,
                 const std::vector<variable> &active)
{
    using P = triangular_set::polynomial_type;
    const auto &frozen = prefix.chain().variables();
    std::set<variable> all(frozen.begin(), frozen.end());
    for (const auto &v : active)
    {
        if (!all.insert(v).second)
        {
            throw std::invalid_argument("PREFIX-ZERO: repeated variable");
        }
    }
    std::map<std::vector<int64_t>, P> coefficients;
    for (const auto &term : p)
    {
        std::vector<int64_t> powers(active.size(), 0);
        basic_monomial<triangular_set::order_type> m(prefix.chain().order());
        for (const auto &ve : term.first)
        {
            if (ve.second < 0 || !all.count(ve.first))
            {
                throw std::invalid_argument("PREFIX-ZERO: invalid variable");
            }
            auto it = std::find(active.begin(), active.end(), ve.first);
            if (it == active.end())
            {
                m.push_back(ve);
            }
            else
            {
                powers[it - active.begin()] = ve.second;
            }
        }
        m.normalization();
        P monomial(prefix.chain().order());
        monomial.push_back({m, QQ(term.second)});
        auto it = coefficients.find(powers);
        if (it == coefficients.end())
        {
            coefficients.emplace(std::move(powers), std::move(monomial));
        }
        else
        {
            it->second = it->second + monomial;
        }
    }
    for (const auto &c : coefficients)
    {
        if (!point_zero(c.second, prefix))
        {
            return false;
        }
    }
    return true;
}
// PDF 算法 8：求导过程中保留未约简的 QQ 代表。
// 预先模三角列约简会破坏需要提取的 Taylor 系数。
template <class C, class Order>
lazard_qq_result lazard_evaluate_qq(const polynomial_<C, Order> &f,
                                    const std::vector<variable> &lifting_order,
                                    const real_algebraic_point &sample)
{
    three_diag::Scope diag_scope("LAZARD");
    if (lifting_order.size() != sample.size() + 1 ||
        std::set<variable>(lifting_order.begin(), lifting_order.end()).size() !=
            lifting_order.size() ||
        !std::equal(sample.chain().variables().begin(), sample.chain().variables().end(),
                    lifting_order.begin()))
    {
        throw std::invalid_argument("LAZARD-QQ: inconsistent variable order");
    }
    if (f.empty())
    {
        throw std::domain_error("LAZARD-QQ: zero input");
    }
    for (const auto &term : f)
    {
        for (const auto &ve : term.first)
        {
            if (ve.second < 0 || std::find(lifting_order.begin(), lifting_order.end(), ve.first) ==
                                     lifting_order.end())
            {
                throw std::invalid_argument("LAZARD-QQ: undeclared variable");
            }
        }
    }
    auto order = std::make_shared<const triangular_set::order_type>(
        custom_var_order(std::vector<variable>(lifting_order.rbegin(), lifting_order.rend())));
    lazard_qq_result result(order);
    poly_convert(f, result.polynomial);
    for (size_t i = 0; i < sample.size(); ++i)
    {
        auto prefix = sample.prefix(i + 1);
        auto h = result.polynomial;
        size_t r = 0;
        ZZ factorial(1);
        std::vector<variable> active(lifting_order.begin() + i + 1, lifting_order.end());
        // 首个非零的导数特化决定本坐标的阶数；在特征零下除以 r!，
        // 得到对应 Taylor 系数的 QQ 代表。
        while (prefix_zero(h, prefix, active))
        {
            h = derivative(h, lifting_order[i]);
            ++r;
            factorial *= ZZ(r);
            if (h.empty())
            {
                throw std::logic_error("LAZARD-QQ: Taylor invariant lost");
            }
        }
        for (auto &term : h)
        {
            term.second /= QQ(factorial);
        }
        result.polynomial = std::move(h);
        result.valuation.push_back(r);
    }
    return result;
}
} // 命名空间 clpoly
#endif
